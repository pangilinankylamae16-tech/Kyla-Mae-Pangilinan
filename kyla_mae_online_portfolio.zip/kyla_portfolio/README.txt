KYLA MAE - ONLINE PORTFOLIO

FILES
- index.html: Home page
- about.html: About, education, skills, and experience
- portfolio.html: Selected academic activities and projects
- contact.html: Contact information and sample contact form
- style.css: External stylesheet used by all pages

HOW TO VIEW
1. Keep all five files in the same folder.
2. Open index.html in a web browser.
3. Use the navigation menu to visit the other pages.

BEFORE SUBMITTING
- Replace the photo placeholder in index.html with your own professional photo if required.
- Add your active email address in contact.html.
- Check that all personal details and project descriptions are accurate.

The contact form is a front-end demonstration only; it does not send messages.
